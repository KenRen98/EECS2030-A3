package org.eecs.a3.teamafk.MLS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MlsApplicationTests {

	@Test
	void contextLoads() {
	}

}
