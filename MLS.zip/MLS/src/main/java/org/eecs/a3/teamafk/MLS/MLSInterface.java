package org.eecs.a3.teamafk.MLS;

/**
 * A Interface for display and further functions
 * @author Ken Ren
 * @version 1.0
 */
public interface MLSInterface {
    String Display();
}
